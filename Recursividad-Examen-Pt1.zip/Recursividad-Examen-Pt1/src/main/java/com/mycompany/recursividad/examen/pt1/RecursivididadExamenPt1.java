package com.mycompany.recursividad.examen.pt1;

import java.util.Scanner;

public class RecursivididadExamenPt1 {

    public static void main(String[] args) {
           System.out.println("Escriba un número la cual se recursivirá");
           Scanner teclado = new Scanner(System.in);
           String recursivo = teclado.nextLine();
           System.out.println(numeroRecursivo(recursivo, recursivo.length()-1));           
    } 
  
    public static String numeroRecursivo(String recursivo, int longitud){
                
            if (longitud == 0){
                
                return recursivo.charAt (longitud)+"";
            }else{
    
            return recursivo.charAt(longitud) + (numeroRecursivo(recursivo, longitud-1));
}
    }
}